script.tvguidetecbox
===============

TEC Guide allows you to combine some of your favourite live TV plugins for use with a fully working EPG.

Based on the original TV Guide by twinther, Dixie, Bluezed, Rayw,

This repository is maintained by tecbox

For official support go to the facebook Group tecbox please

**PLEASE NOTE:** 
This TV guide has been re skinned using the original developers code all credits must go to them ie FXB78,Bluezed tommy winther dixie Ray Wilson as without them there
would not be a tv guide 